* * * * * bash /Users/bin4xin/blog/github-code/Bin4xin/.git/hooks/HOOK_B4xinSynchronize
