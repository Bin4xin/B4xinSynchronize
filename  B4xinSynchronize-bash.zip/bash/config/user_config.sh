##############
###dw mode:###
##############
# project 0: bin4xin_github_io options
options_project_0="bin4xin_github_io"
_dw_bin4xin_github_io_gitPath="/Users/bin4xin/blog/github-code/bin4xin.github.io"
_dw_bin4xin_github_io_buildPath="/Users/bin4xin/blog/SENTRYLAB-WWW-WEB/_site"

# project 1: bin4xin_gitee_io options
options_project_1="bin4xin_gitee_io"
_dw_bin4xin_gitee_io_gitPath="/Users/bin4xin/blog/gitee-code/bin4xin"
_dw_bin4xin_gitee_io_buildPath="/Users/bin4xin/blog/SENTRYLAB-WWW-WEB/_site"

# project 2: sentrylab_tokyo_www options
options_project_2="sentrylab_tokyo_www"
_dw_sentrylab_tokyo_www_gitPath="/Users/bin4xin/blog/git-www-update/sentrylab-tokyo/www"
_dw_sentrylab_tokyo_www_buildPath="/Users/bin4xin/blog/SENTRYLAB-WWW-WEB/_site"

# project 3: sentrylab_tokyo_about options
options_project_3="sentrylab_tokyo_about"
_dw_sentrylab_tokyo_about_gitPath="/Users/bin4xin/blog/git-www-update/sentrylab-tokyo/about"
_dw_sentrylab_tokyo_about_buildPath="/Users/bin4xin/blog/SENTRYLAB-ABOUT-WEB/_site"

##############
###sw mode:###
##############
# project 4: B4xinSynchronize options
options_project_4="B4xinSynchronize"
_sw_B4xinSynchronize_gitPath="/Users/bin4xin/blog/github-code/B4xinSynchronize"

# project 5: sweet_ysoserial options
options_project_5="sweet_ysoserial"
_sw_sweet_ysoserial_gitPath="/Users/bin4xin/blog/github-code/sweet-ysoserial"

# project 6 Bin4xin options
options_project_6="Bin4xin"
_sw_Bin4xin_gitPath="/Users/bin4xin/blog/github-code/Bin4xin"

# project 7 bigger_than_bigger options
options_project_7="bigger_than_bigger"
_sw_bigger_than_bigger_gitPath="/Users/bin4xin/blog/github-code/bigger-than-bigger"

# project 8 Industrial_Control_Wiki_Record options
options_project_8="Industrial_Control_Wiki_Record"
_sw_Industrial_Control_Wiki_Record_gitPath="/Users/bin4xin/blog/github-code/Industrial-Control-Wiki-Record"